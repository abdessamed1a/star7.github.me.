<?php
require_once('Shimmie2Bridge.php');

class DollbooruBridge extends Shimmie2Bridge {
	const MAINTAINER = 'mitsukarenai';
	const NAME = 'Dollbooru';
	const URI = 'http://dollbooru.org/';
	const DESCRIPTION = 'Returns images from given page';
}
