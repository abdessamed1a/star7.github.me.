<?php
require_once('MoebooruBridge.php');

class LolibooruBridge extends MoebooruBridge {

	const MAINTAINER = 'mitsukarenai';
	const NAME = 'Lolibooru';
	const URI = 'https://lolibooru.moe/';
	const DESCRIPTION = 'Returns images from given page and tags';

}
