<?php
require_once('MoebooruBridge.php');

class SakugabooruBridge extends MoebooruBridge {

	const MAINTAINER = 'mitsukarenai';
	const NAME = 'Sakugabooru';
	const URI = 'http://sakuga.yshi.org/';
	const DESCRIPTION = 'Returns images from given page';

}
